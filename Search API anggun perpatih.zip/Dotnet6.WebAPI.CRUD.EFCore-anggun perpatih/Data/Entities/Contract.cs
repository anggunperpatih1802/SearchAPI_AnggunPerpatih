﻿namespace Dot6.API.Crud.Data.Entities
{
    public class Contract
    {
        public int Contractid { get; set; }
        public int Nationalid { get; set; }
        public string? SubjectRole_RoleOfCustomer { get; set; }
        public string? PhaseOfContract { get; set; }
        public decimal? OriginalAmount_Value { get; set; }
        public string? OriginalAmount_Currency { get; set; }
        public decimal? InstallmentAmount_Value { get; set; }
        public string? InstallmentAmount_Currency { get; set; }
        public DateTime? DateOfLastPayment { get; set; }
        public DateTime? DateOfNextPayment { get; set; }

        public DateTime? DateAccountOpened { get; set; }
        public decimal? GuaranteeAmount { get; set; }
    }
}
