﻿namespace Dot6.API.Crud.Data.Entities
{
    public class Individual
    {
        public int Individualid { get; set; }
        public string Surname { get; set; }
        public string Lastname { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Gender { get; set; }
        public int Nationalid { get; set; }

    }
}
