using Dot6.API.Crud.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Dot6.API.Crud.Data;

public class MyWorldDbContext : DbContext
{
    public MyWorldDbContext(DbContextOptions<MyWorldDbContext> options) : base(options)
    {

    }
    public DbSet<Contract> Contract { get; set; }
    public DbSet<Individual> Individual { get; set; }

}