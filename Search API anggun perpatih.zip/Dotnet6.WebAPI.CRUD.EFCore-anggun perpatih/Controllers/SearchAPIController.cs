﻿using Dot6.API.Crud.Data;
using Dot6.API.Crud.Data.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace Dot6.API.Crud.Controllers;
[ApiController]
[Route("[controller]")]
public class SearchAPIController : ControllerBase
{
    private readonly MyWorldDbContext _myWorldDbContext;
    public SearchAPIController(MyWorldDbContext myWorldDbContext)
    {
        _myWorldDbContext = myWorldDbContext;
    }


    [HttpGet]
    [Route("get-individual-by-NationalId")]
    public async Task<IActionResult> GetDetailIndividualByIdAsync(int id)
    {
        var person = (from p in _myWorldDbContext.Individual
                      join e in _myWorldDbContext.Contract
                      on p.Nationalid equals e.Nationalid
                      where p.Nationalid == id
                      select new
                      {
                          ID = p.Nationalid,
                          FirstName = p.Surname.Trim(),
                          MiddleName = p.Lastname.Trim(),
                          Dob= p.DateOfBirth,
                          Gender = p.Gender.Trim(),
                          RoleofCustommer =e.SubjectRole_RoleOfCustomer.Trim(),
                          PhaseofContract = e.PhaseOfContract.Trim(),
                          OriginalAmountValue = e.OriginalAmount_Value.ToString().Trim(),
                          OriginalAmountCurrency = e.OriginalAmount_Currency.Trim(),
                          InstallmentAmountValue= e.InstallmentAmount_Value.ToString().Trim(),
                          InstallmentAmountCurrency= e.InstallmentAmount_Currency.Trim(),
                          DateLastPayment= e.DateOfLastPayment,
                          DateAccountOpened= e.DateAccountOpened,
                          GuarantedAmount = e.GuaranteeAmount.ToString().Trim()
                      }).ToList();
        
        return Ok(person);
    }

    [HttpPost]
    [Route("Post-individual")]
    public async Task<IActionResult> PostAsync(Individual individual)
    {
        try{
            int age = 0;
            var today = DateTime.Today;

            var a = (today.Year * 100 + today.Month) * 100 + today.Day;
            var b = (individual.DateOfBirth.Value.Year * 100 + individual.DateOfBirth.Value.Month) * 100 + individual.DateOfBirth.Value.Day;

             age= (a - b) / 10000;

            if ((age < 18) || (age > 99))

            {
                throw new Exception("DateOfBirth attribute value must be between 18 and 99 years");
            }else
            {
                _myWorldDbContext.Individual.Add(individual);
                await _myWorldDbContext.SaveChangesAsync();

            }

        }
        catch (Exception ex)
        {
            throw new Exception("DateOfBirth attribute value must be between 18 and 99 years");
        }
        return Created($"/get-individual-by-NationalId?id={individual.Nationalid}", individual);

    }
    [HttpPost]
    [Route("Post-Contract")]
    public async Task<IActionResult> CPostAsync(Contract contract)
    {
        Individual individual = new Individual();
        try
        {

            if (contract.DateOfLastPayment > contract.DateOfNextPayment)

            {
                throw new Exception("Contract.DateAccountOpened attribute value must be before (in time) Contract.DateOfLastPayment attribute value");
            }
            if (contract.DateAccountOpened > contract.DateOfLastPayment)

            {
                throw new Exception("Contract.DateOfLastPayment attribute value must be before (in time) Contract.NextPaymentDate attribute value");
            }

            _myWorldDbContext.Contract.Add(contract);
                await _myWorldDbContext.SaveChangesAsync();

        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return Created($"/get-individual-by-NationalId?id={individual.Nationalid}", individual);

    }
}
